package com.example.vinsol_assignment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

class ListViewAdapter extends ArrayAdapter<Meeting> {
    private List<Meeting> meetingList;
    private Context mCtx;

    public static String start_time_tv;
    public static String end_time_tv;

    public ListViewAdapter(List<Meeting> meetingList,Context mCtx) {


            super(mCtx, R.layout.list_items, meetingList);
            this.meetingList = meetingList;
            this.mCtx = mCtx;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //getting the layoutinflater
        LayoutInflater inflater = LayoutInflater.from(mCtx);

        //creating a view with our xml layout
        View listViewItem = inflater.inflate(R.layout.list_items, null, true);

        //getting text views
        TextView startTime = listViewItem.findViewById(R.id.start_time);
        TextView endTime = listViewItem.findViewById(R.id.end_time);
        TextView dummy_text = listViewItem.findViewById(R.id.text);

        //Getting the hero for the specified position
        Meeting meeting = meetingList.get(position);

        //setting hero values to textviews
        startTime.setText(meeting.getStart_time());
        endTime.setText(meeting.getEnd_time());
dummy_text.setText(meeting.getDescription());
 start_time_tv=meeting.getStart_time();
 end_time_tv=meeting.getEnd_time();
        //returning the listitem
        return listViewItem;
    }
}