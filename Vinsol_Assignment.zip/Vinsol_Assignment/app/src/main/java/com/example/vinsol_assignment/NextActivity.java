package com.example.vinsol_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class NextActivity extends AppCompatActivity implements View.OnClickListener {
    ImageButton back;
    Button schedule_button;
    ImageButton date_picker, start_time, end_time;
    EditText date, starttime_editText, endtime_editText;
    private int mYear, mMonth, mDay, mHour, mMinute;
    static int time [] = new int[1440];
    String s[] =   {"15:30","1:30","1:15","15:00"};
    String e[] = {"18:35","13:28","1:30","15:29"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
        date_picker = (ImageButton) findViewById(R.id.date_picker);
        date_picker.setOnClickListener(this);
        start_time = (ImageButton) findViewById(R.id.start_time_picker);
        start_time.setOnClickListener(this);

        end_time = (ImageButton) findViewById(R.id.end_time_picker);
        end_time.setOnClickListener(this);
        back=(ImageButton)findViewById(R.id.back_button) ;
        back.setOnClickListener(this);
        date = (EditText) findViewById(R.id.in_date);
        starttime_editText = (EditText) findViewById(R.id.start_time);
        endtime_editText = (EditText) findViewById(R.id.end_time);
        schedule_button=(Button)findViewById(R.id.submit_button);
        schedule_button.setOnClickListener(this);


    }
    @Override
    public void onClick(View view) {
        if(view==back){
            super.onBackPressed();
        }
        else if(view==date_picker)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();

        }
        else if(view==start_time){

            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            starttime_editText.setText(hourOfDay + ":" + minute);

                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }

        else if(view==end_time){
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            endtime_editText.setText(hourOfDay + ":" + minute);
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
        else if(view==schedule_button)
        {
            String message="Meeting scheduled";
            String message2="meeting not scheduled";
            System.out.println(scheduler(s,e));
           boolean result=scheduler(s,e);
           if(result){
               Toast.makeText(getApplicationContext(),message,Toast.LENGTH_LONG).show();


           }
           else
           {
               Toast.makeText(getApplicationContext(),message2,Toast.LENGTH_LONG).show();
           }

            //String message="Meeting scheduled";
            //if(scheduler(s,e)){
            // Toast.makeText(getApplicationContext(),message,Toast.LENGTH_LONG);
            // Log.e("scheduler","hello");
        }

    }

    public static int calculateMinute(int hour, int minute){
        return hour*60+minute;
    }
    public static boolean timeClashChecker(int start, int end){
        for(int i=start;i<=end;i++){
            if(i==end){
                time[i] =  -1;
            }
            else if(time[i]==1){
                return false;
            }
            else if(time[i]==-1){
                time[i]=1;
            }
            else{
                time[i]=1;
            }
        }
        return true;
    }

    public static int parser(String time){
        String [] timeParts = time.split(":");
        int hour = Integer.parseInt(timeParts[0].trim());
        int minute = Integer.parseInt(timeParts[1].trim());

        return calculateMinute(hour,minute);
    }
    public static boolean scheduler(String start[], String end[]){

        for(int i=0;i<start.length;i++){
            int startMeeting = parser(start[i]);
            int endMeeting = parser(end[i]);
            boolean result = timeClashChecker(startMeeting,endMeeting);
            if(result == false){ //clash check
                return false;
            }
            else
                return true;
        }
       return true;
    }


        }







