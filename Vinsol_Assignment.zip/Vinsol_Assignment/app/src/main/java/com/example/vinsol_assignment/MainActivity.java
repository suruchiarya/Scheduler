package com.example.vinsol_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String JSON_URL = "http://fathomless-shelf-5846.herokuapp.com/api/schedule?date=\"7/8/2015\"";
    ListView listView;
Button schedule_button;
    //the hero list where we will store all the hero objects after parsing json
    List<Meeting> meetingList;
ImageButton next_button,prev_button;
TextView date_textview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        androidx.appcompat.widget.Toolbar toolbar=(androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar);

        next_button=(ImageButton)findViewById(R.id.next);
        next_button.setOnClickListener(this);
        prev_button=(ImageButton)findViewById(R.id.prev) ;
        prev_button.setOnClickListener(this);
          schedule_button=(Button)findViewById(R.id.schedule_button);
          schedule_button.setOnClickListener(this);
        listView = (ListView) findViewById(R.id.listView);
        meetingList = new ArrayList<>();
date_textview=(TextView)findViewById(R.id.date);
        Date c = Calendar.getInstance().getTime();
        System.out.println("Current time => " + c);

        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = df.format(c);
        date_textview.setText(formattedDate);
        load();
    }

    private void setSupportActionBar(Toolbar toolbar) {
    }

    private void load() {


        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.GET, JSON_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //getting the whole json object from the response
                            JSONArray obj = new JSONArray(response);
for(int i=0;i<obj.length();i++){
    JSONObject m=obj.getJSONObject(i);
    Meeting meeting = new Meeting(m.getString("start_time"), m.getString("end_time"),m.getString("description"),m.getString("participants"));
meetingList.add(meeting);
}


                            //creating custom adapter object
                            ListViewAdapter adapter = new ListViewAdapter(meetingList, getApplicationContext());

                            //adding the adapter to listview
                            listView.setAdapter(adapter);
                            Log.d("hello",listView.toString());

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }

    @Override
    public void onClick(View view) {
        if(view==schedule_button)
        {
            Intent intent=new Intent(MainActivity.this,NextActivity.class);
            startActivity(intent);
        }
        else if(view==next_button){
            load();
        }
        else if(view==prev_button){
            load();
        }
    }
}

